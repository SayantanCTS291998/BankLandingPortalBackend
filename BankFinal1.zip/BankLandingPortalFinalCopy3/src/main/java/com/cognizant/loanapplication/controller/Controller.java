package com.cognizant.loanapplication.controller;


import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.loanapplication.dtos.EmiClacDTO;
import com.cognizant.loanapplication.dtos.LoanAppDTO;
import com.cognizant.loanapplication.dtos.LoanAppDTOResponse;
import com.cognizant.loanapplication.dtos.LoanApplicationDTO;
import com.cognizant.loanapplication.dtos.LoanDTO;
import com.cognizant.loanapplication.dtos.LoanStatusDTO;
import com.cognizant.loanapplication.dtos.ReducePaymentDTO;
import com.cognizant.loanapplication.service.LoanApplicationService;

import jakarta.validation.Valid;



@RestController
@RequestMapping("/api/loanapps")
public class Controller {
	
	@Autowired
	LoanApplicationService loanServiceImpl;

	
	
	///api/loanapps/pull/<date> (1)
	@GetMapping("/pull/{date}")
	public ResponseEntity<List<LoanApplicationDTO>> findApplicationByDate(@Valid @PathVariable("date") LocalDate dt){
		List<LoanApplicationDTO> loanApplicationDto=loanServiceImpl.loanApplicationFindByDate(dt);
		if(loanApplicationDto.isEmpty()) {
			return new ResponseEntity<>(null,HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(loanApplicationDto,HttpStatus.OK);
	}
	
	
	
	///api/ loanapps/view/<loan_ap_id> (2)
	@PutMapping("/update/{id}")
	public ResponseEntity<LoanApplicationDTO> updateById(@Valid @RequestBody LoanApplicationDTO loanApplicationDto, @PathVariable("id") String id){
		LoanApplicationDTO loanApplicationDto1=loanServiceImpl.loanApplicationUpdateById(loanApplicationDto, id);
		return new ResponseEntity<>(loanApplicationDto1,HttpStatus.OK);
	}
	
	
	///api/loanapps/update/<loan_ap_id> (3)
	@GetMapping("/view/{loan_app_id}")
	public ResponseEntity<LoanApplicationDTO> getById(@Valid @PathVariable("loan_app_id") String loan_app_id ){
		return ResponseEntity.ok(this.loanServiceImpl.loanApplicationFindById(loan_app_id));
	}
	
	
	@PutMapping("/basicCheck")
	public ResponseEntity<LoanStatusDTO> updateBasicCheck(@RequestBody LoanAppDTO loanAppDto){
		return new ResponseEntity<>(this.loanServiceImpl.performBasicCheck(loanAppDto),HttpStatus.OK);
	}
	
	
	
	
	//api/loanapps/checkEm - GET , I-LoanDTO , O - EmiClacDTO (5)
	@GetMapping("/checkEmi")
	public ResponseEntity<EmiClacDTO> claculateEmi(@RequestBody LoanDTO loanDto){
		System.out.println(loanDto);
		EmiClacDTO emiClacDto=this.loanServiceImpl.calculateEmi(loanDto);
		return new ResponseEntity<>(emiClacDto,HttpStatus.OK);
	}
	
	
//	creditScore (6)
	@PutMapping("/creditscore")
	public ResponseEntity<LoanStatusDTO> getAllCreditScore(@Valid @RequestBody LoanAppDTO loanAppDto){
		LoanStatusDTO loanStatusDtos=this.loanServiceImpl.fetchCreditScore(loanAppDto);
		return new ResponseEntity<>(loanStatusDtos,HttpStatus.OK);
	}
	
	//api/loanapps/checkCustomerAcceptanceStatus/<loanAppID> GET, I- LoanAppId, O-LOanAppDTO (7)
	@GetMapping("/checkCustomerAcceptanceStatus/{loanAppID}")
	public ResponseEntity<LoanAppDTOResponse> checkCustomerAcceptanceStatus(@PathVariable("loanAppID") String loanAppID){
		LoanAppDTOResponse loanAppDtoResponse=this.loanServiceImpl.fetchAcceptance(loanAppID);
		return new ResponseEntity<>(loanAppDtoResponse,HttpStatus.OK);
	}
	
	
	//api/loanapps/sanctionAmount/<loanAppID> GET , I-loanAppID , O- ReducePaymentDTO (8)
	@GetMapping("sanctionAmount/{loanAppID}")
	public ResponseEntity<List<ReducePaymentDTO>> sanctionLoanAmount(@PathVariable("loanAppID") String loanAppID ){
		List<ReducePaymentDTO> reducePaymentDto=this.loanServiceImpl.acceptenceReducePayment(loanAppID);
		return new ResponseEntity<>(reducePaymentDto,HttpStatus.OK);
	}
	
}
