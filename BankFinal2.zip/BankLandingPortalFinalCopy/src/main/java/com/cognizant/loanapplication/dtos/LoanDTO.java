package com.cognizant.loanapplication.dtos;

import java.time.LocalDate;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class LoanDTO {
	@NotEmpty(message = "Loan Application Id can't be null or Empty")
	private String loanAppId;
	@Positive(message = "Value must be positive")
	private double principleAmount;
	@Positive(message = "Value must be positive")
	private double monthlyinterestRate;
	@Positive(message = "Value must be positive")
	private int loanTenureMonths;
	@Positive(message = "Value must be positive")
	private double emi;
	@Positive(message = "Value must be positive")
	private double totalAmountPayable;
	@NotEmpty(message = "Due Date Id can't be null or Empty")
	private LocalDate dueDate;
}
