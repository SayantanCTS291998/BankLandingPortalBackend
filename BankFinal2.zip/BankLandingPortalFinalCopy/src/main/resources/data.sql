


insert into Loan_Application(loan_appid,cust_id,loan_amt,no_of_years,purpose,app_status,type_of_loan,loan_app_date,status)
 values('L100','CR100',30000,3,'Use','accpted','Personal Loan','2023-10-21','accepted');
insert into Loan_Application values('L101','CRL101',10000,9,'Use','rejected','Home Loan','2023-09-01','rejected');
insert into Loan_Application values('L102','CR102',20000,8,'Use','accepted','Car Loan','2023-10-21','accepted');
 
 insert into Credit_Risk values('CRL100','L100',650,67987,'pass');
 insert into Credit_Risk values('CRL101','L101',750,67888,'fail')