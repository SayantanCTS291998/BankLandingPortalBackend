package com.cognizant.loanmanagement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cognizant.loanapplication.dtos.EmiClacDTO;
import com.cognizant.loanapplication.dtos.LoanAppDTO;
import com.cognizant.loanapplication.dtos.LoanAppDTOResponse;
import com.cognizant.loanapplication.dtos.LoanApplicationDTO;
import com.cognizant.loanapplication.dtos.LoanDTO;
import com.cognizant.loanapplication.dtos.LoanStatusDTO;
import com.cognizant.loanapplication.dtos.ReducePaymentDTO;
import com.cognizant.loanapplication.entities.CreditRisk;
import com.cognizant.loanapplication.entities.LoanApplication;
import com.cognizant.loanapplication.exception.ResourceNotFoundException;
import com.cognizant.loanapplication.modelmapper.ModelMap;
import com.cognizant.loanapplication.repositories.CreditRiskRepository;
import com.cognizant.loanapplication.repositories.LoanApplicationRepository;
import com.cognizant.loanapplication.serviceimpl.LoanApplicationServiceImpl;


public class LoanApplicationServiceTest {
	@Mock
    private ModelMap modelmapper;
	
	@Mock
	private LoanApplicationRepository loanAppRepository;
	@Mock
	private LoanApplicationDTO loanApplicationDTO;
	
	@Mock
	private CreditRiskRepository creditRiskRepository;
	@InjectMocks
	private LoanApplicationServiceImpl loanApplicationServiceImpl;
	
	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		
	    LoanApplicationDTO loanApplicationDTO=new LoanApplicationDTO();
	    loanApplicationDTO.setLoanAppId("Hello");
		loanApplicationDTO.setCustId("CUHello");
     	loanApplicationDTO.setLoanAmt(4895);
		loanApplicationDTO.setNoOfYears(5);
		loanApplicationDTO.setPurpose("BBB");
		loanApplicationDTO.setAppStatus("accpted");
		loanApplicationDTO.setTypeOfLoan("Home Loan");
		loanApplicationDTO.setLoanAppDate(LocalDate.now());
		loanApplicationDTO.setStatus("fail");
		
		LoanApplication loanApplication=new LoanApplication();
	    loanApplication.setLoanAppId("Hello");
		loanApplication.setCustId("CUHello");
     	loanApplication.setLoanAmt(4895);
		loanApplication.setNoOfYears(5);
		loanApplication.setPurpose("BBB");
		loanApplication.setAppStatus("accepted");
		loanApplication.setTypeOfLoan("Home Loan");
		loanApplication.setLoanAppDate(LocalDate.now());
		loanApplication.setStatus("fail");
	}
	
	
//==============================================(1)====================================================
	@Test
	public void test_LoanApplicationFindByDatePositive() {
		List<LoanApplication> loanApplications= new ArrayList<LoanApplication>();
		loanApplications.add(new LoanApplication("BBB","CUBBB",47488,7,"skjf","slmls","dfsd",LocalDate.now(),"ksndk", null));
		loanApplications.add(new LoanApplication("BBB","CUBBB",47488,7,"skjf","slmls","dfsd",LocalDate.now(),"ksndk", null));
		when(loanAppRepository.findAllByLoanAppDate(LocalDate.now())).thenReturn(loanApplications);
		when(modelmapper.entityToDto(loanApplications.get(0))).thenReturn(loanApplicationDTO);
		assertTrue(loanApplicationServiceImpl.loanApplicationFindByDate(LocalDate.now())!=null);
	}
	@Test
	public void test_LoanApplicationFindByDateNegetive() {
		try {
			when(loanAppRepository.findAllByLoanAppDate(LocalDate.now())).thenThrow(ResourceNotFoundException.class);
			loanApplicationServiceImpl.loanApplicationUpdateById(loanApplicationDTO,anyString());
			
		}catch(Exception e) {
			assertTrue(e instanceof ResourceNotFoundException);
		}
	}

	
//=======================================(2)=========================================================

	@Test
	public void test_LoanApplicationUpdateByIdPositive() {
		String appId="NOi123";
		//act
		LoanApplicationDTO loanAppDto=new LoanApplicationDTO();
		loanAppDto.setLoanAppId(appId);
		loanAppDto.setPurpose("invalid");
		
		
		//Act
		
		LoanApplication LoanAppEntity=new LoanApplication();
		LoanAppEntity.setLoanAppId(appId);
		LoanAppEntity.setPurpose("Valid");
		
		
		when(loanAppRepository.findById(appId)).thenReturn(Optional.of(LoanAppEntity));
		when(loanAppRepository.save(LoanAppEntity)).thenReturn(LoanAppEntity); 
		when(modelmapper.entityToDto(LoanAppEntity)).thenReturn(loanAppDto);
		LoanApplicationDTO updatedLoanAppDto= loanApplicationServiceImpl.loanApplicationUpdateById(loanAppDto, appId);
		
		assertNotNull(updatedLoanAppDto);
		assertEquals(updatedLoanAppDto.getLoanAppId(),loanAppDto.getLoanAppId());
		assertEquals(updatedLoanAppDto.getPurpose(),"invalid");
		
	}
	

	
	@Test
	public void test_loanApplicationUpdateByIdNotFoundException() {
		try {
			when(loanAppRepository.findById(anyString())).thenThrow(ResourceNotFoundException.class);
			loanApplicationServiceImpl.loanApplicationUpdateById(loanApplicationDTO,anyString());
			
		}catch(Exception e) {
			assertTrue(e instanceof ResourceNotFoundException);
		}
	}
//==========================================(3)======================================================
	
	@Test
	public void loanApplicationFindByIdPositive() {
		LoanApplicationDTO loanApplicationDTO=new LoanApplicationDTO();
	    loanApplicationDTO.setLoanAppId("Hello");
		loanApplicationDTO.setCustId("CUHello");
     	loanApplicationDTO.setLoanAmt(4895);
		loanApplicationDTO.setNoOfYears(5);
		loanApplicationDTO.setPurpose("BBB");
		loanApplicationDTO.setAppStatus("accpted");
		loanApplicationDTO.setTypeOfLoan("Home Loan");
		loanApplicationDTO.setLoanAppDate(LocalDate.now());
		loanApplicationDTO.setStatus("fail");
		
		LoanApplication loanApplication=new LoanApplication();
	    loanApplication.setLoanAppId("Hello");
		loanApplication.setCustId("CUHello");
     	loanApplication.setLoanAmt(4895);
		loanApplication.setNoOfYears(5);
		loanApplication.setPurpose("BBB");
		loanApplication.setAppStatus("accpted");
		loanApplication.setTypeOfLoan("Home Loan");
		loanApplication.setLoanAppDate(LocalDate.now());
		loanApplication.setStatus("fail");
		when(loanAppRepository.findById(anyString())).thenReturn(Optional.of(loanApplication));
		when(modelmapper.entityToDto(loanApplication)).thenReturn(loanApplicationDTO);
		LoanApplicationDTO dto=loanApplicationServiceImpl.loanApplicationFindById("Hello");
		assertTrue(dto.getLoanAppId()!=null);
	}
	
	@Test
	public void loanApplicationFindByIdNotFoundException() {
		try {
			when(loanAppRepository.findById(anyString())).thenThrow(ResourceNotFoundException.class);
			loanApplicationServiceImpl.loanApplicationUpdateById(loanApplicationDTO,anyString());
			
		}catch(Exception e) {
			assertTrue(e instanceof ResourceNotFoundException);
		}
	}
//===========================================(4)======================================================
	@Test
	public void test_PerformBasicCheckAcceptedPositive() {
		CreditRisk creditRisk=new CreditRisk();
		LoanAppDTO loanAppDto=new LoanAppDTO();
		loanAppDto.setAge(30);
		loanAppDto.setNoOfYears(0);
		LoanApplication loanApplication=new LoanApplication();
		when(loanAppRepository.findById(loanAppDto.getLoanAppId())).thenReturn(Optional.of(loanApplication));
		when(creditRiskRepository.save(Mockito.any())).thenReturn(creditRisk);
		LoanStatusDTO loanStatusDto=loanApplicationServiceImpl.performBasicCheck(loanAppDto);
		assertTrue(loanStatusDto!=null);
		assertEquals(loanStatusDto.getFinalcheck(),"accepted");
	}
	
	@Test
	public void test_PerformBasicCheckAcceptedNegetive() {
		CreditRisk creditRisk=new CreditRisk();
		LoanAppDTO loanAppDto=new LoanAppDTO();
		loanAppDto.setAge(30);
		loanAppDto.setNoOfYears(40);
		LoanApplication loanApplication=new LoanApplication();
		when(loanAppRepository.findById(loanAppDto.getLoanAppId())).thenReturn(Optional.of(loanApplication));
		when(creditRiskRepository.save(Mockito.any())).thenReturn(creditRisk);
		LoanStatusDTO loanStatusDto=loanApplicationServiceImpl.performBasicCheck(loanAppDto);
		assertTrue(loanStatusDto!=null);
		assertEquals(loanStatusDto.getFinalcheck(),"rejected");
	}
	
//===========================================(5)=======================
	@Test
	public void testCalculateEmiPositive() {
        // Arrange
		LoanDTO loan=new LoanDTO();
		loan.setDueDate(LocalDate.now());
		loan.setEmi(8775);
		loan.setLoanAppId("L123");
		loan.setLoanTenureMonths(12);
		loan.setMonthlyinterestRate(1.5);
		loan.setPrincipleAmount(100000);
		loan.setTotalAmountPayable(105300);
        EmiClacDTO result = loanApplicationServiceImpl.calculateEmi(loan);
        assertNotNull(result.getEmi());
        assertNotNull(result.getTotalAmountPayable());
    }
	
	@Test
	public void testCalculateEmiNegetive() {
		LoanDTO loan=new LoanDTO();
		EmiClacDTO result = loanApplicationServiceImpl.calculateEmi(loan);
        assertEquals(0, result.getEmi());
	}
//===========================================(6)======================================================
	@Test
	public void test_FetchCreditScorePositive() {
		CreditRisk creditRisk=new CreditRisk();
		LoanAppDTO loanAppDto=new LoanAppDTO();
		loanAppDto.setAge(30);
		loanAppDto.setNoOfYears(0);
		LoanApplication loanApplication=new LoanApplication();
		when(loanAppRepository.findById(loanAppDto.getLoanAppId())).thenReturn(Optional.of(loanApplication));
		when(creditRiskRepository.save(Mockito.any())).thenReturn(creditRisk);
		LoanStatusDTO loanStatusDto=loanApplicationServiceImpl.fetchCreditScore(loanAppDto);
		assertTrue(loanStatusDto!=null);
		assertEquals(loanStatusDto.getFinalcheck(),"accepted");
	}
	
	@Test
	public void test_FetchCreditScoreNegetive() {
		CreditRisk creditRisk=new CreditRisk();
		LoanAppDTO loanAppDto=new LoanAppDTO();
		loanAppDto.setAge(30);
		loanAppDto.setNoOfYears(40);
		LoanApplication loanApplication=new LoanApplication();
		when(loanAppRepository.findById(loanAppDto.getLoanAppId())).thenReturn(Optional.of(loanApplication));
		when(creditRiskRepository.save(Mockito.any())).thenReturn(creditRisk);
		LoanStatusDTO loanStatusDto=loanApplicationServiceImpl.fetchCreditScore(loanAppDto);
		assertTrue(loanStatusDto!=null);
		assertEquals(loanStatusDto.getFinalcheck(),"rejected");
	}
	
	
	
//===========================================(7)======================================================
//	

	@Test
	public void test_FetchAcceptanceIfPart() {
		LoanApplication loanApplication=new LoanApplication();
	    loanApplication.setLoanAppId("Hello");
		loanApplication.setCustId("CUHello");
     	loanApplication.setLoanAmt(4895);
		loanApplication.setNoOfYears(5);
		loanApplication.setPurpose("BBB");
		loanApplication.setAppStatus("accepted");
		loanApplication.setTypeOfLoan("Home Loan");
		loanApplication.setLoanAppDate(LocalDate.now());
		loanApplication.setStatus("accepted");
		when(loanAppRepository.findById("Hello")).thenReturn(Optional.of(loanApplication));
		LoanAppDTOResponse loanappdto1= loanApplicationServiceImpl.fetchAcceptance("Hello");
		assertEquals(loanappdto1.getReducePayment(),5000);
	}
	@Test
	public void test_FetchAcceptanceElsePart() {
		LoanApplication loanApplication=new LoanApplication();
	    loanApplication.setLoanAppId("Hello");
		loanApplication.setCustId("CUHello");
     	loanApplication.setLoanAmt(4895);
		loanApplication.setNoOfYears(5);
		loanApplication.setPurpose("BBB");
		loanApplication.setAppStatus("accepted");
		loanApplication.setTypeOfLoan("Home Loan");
		loanApplication.setLoanAppDate(LocalDate.now());
		loanApplication.setStatus("rejected");
		when(loanAppRepository.findById(anyString())).thenReturn(Optional.of(loanApplication));
		LoanAppDTOResponse loanappdto1= loanApplicationServiceImpl.fetchAcceptance("Hello");
		assertEquals(0,loanappdto1.getReducePayment());
		assertEquals( loanappdto1.getCustomerAcceptanceStatus(),"rejected");
	}
	@Test
	public void test_FetchAcceptanceException() {
		try {
			when(loanAppRepository.findById(anyString())).thenThrow(ResourceNotFoundException.class);
			LoanAppDTOResponse updatedLoanAppDto= loanApplicationServiceImpl.fetchAcceptance(anyString());
		}catch(Exception e) {
			assertTrue(e instanceof ResourceNotFoundException);
		}
	}
//=============================================(8)===================================================
	@Test
	public void test_AcceptenceReducePayment_Positive() {
		LoanApplication loanApplication=new LoanApplication();
	    loanApplication.setLoanAppId("Hello");
		loanApplication.setCustId("CUHello");
     	loanApplication.setLoanAmt(4895);
		loanApplication.setNoOfYears(5);
		loanApplication.setPurpose("BBB");
		loanApplication.setAppStatus("accpted");
		loanApplication.setTypeOfLoan("Home Loan");
		loanApplication.setLoanAppDate(LocalDate.now());
		loanApplication.setStatus("fail");
		when(loanAppRepository.findById("Hello")).thenReturn(Optional.of(loanApplication));
		List<ReducePaymentDTO> reducePayments=loanApplicationServiceImpl.acceptenceReducePayment("Hello");
		assertTrue(reducePayments.size()>0);
		
	}
	@Test
	public void test_AcceptenceReducePayment_Negetive() {
		try {
			when(loanAppRepository.findById(anyString())).thenThrow(ResourceNotFoundException.class);
			loanApplicationServiceImpl.acceptenceReducePayment(anyString());
		}catch(Exception e) {
			assertTrue(e instanceof ResourceNotFoundException);
		}
	}
}
